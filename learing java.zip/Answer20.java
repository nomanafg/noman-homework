
package answer20;

import java.util.Scanner;

public class Answer20 {

    public static void main(String[] args) {
        Scanner Scanner = new Scanner(System.in);
        System.out.println("enter the string of number :");
        String input = Scanner.nextLine();
        if (isPalindrome(input)){System.out.println("'"+input+"is a palindrome.");}
        else {System.out.println("'"+input+"'is not a palindrome.");}
        }

    private static boolean isPalindrome(Scanner input) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private static boolean isPalindrome(String input) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
                 

        
    }
    
    
    

