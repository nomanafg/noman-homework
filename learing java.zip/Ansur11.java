
package ansur11;


public class Ansur11 {


    public static void main(String[] args) {
        byte x = 120;
        int y = x ;
        System.out.println(y);
    }
    
}
