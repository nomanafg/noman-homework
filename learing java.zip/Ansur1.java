
package declarvarible;

public class DeclarVarible {

   
    public static void main(String[] args) {

    int x;
    x = 5;
   System.out.println("The value of x is "+ x );}
   
}
