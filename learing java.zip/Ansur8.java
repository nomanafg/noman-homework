
package ansur.pkg8;


public class Ansur8 {


    public static void main(String[] args) {
        int x = 44 ;
        int y = 23;
        System.out.println(x>y);
        System.out.println(y<x);
        System.out.println(x>=y);
        System.out.println(y<=x);
        System.out.println(x!=y);
    }
    
}
