package ansur10;

public class Ansur10 {

    public static void main(String[] args) {
        boolean a = 5 > 3;
        boolean b = 7 < 5;
        System.out.println(a && b);
        System.out.println(a || b);
        System.out.println(a != b);
    }

}
