package ansur9;

public class Ansur9 {

    public static void main(String[] args) {{
        int x = 5;
        x += 4;
      
        System.out.println(" x+=4 = "+ x);
   int y =5;
   y-=4;
        System.out.println("y-=4 = " +y);
        int z=5;
        z*=3;
        System.out.println("z*=3 = "+z);
          int w=6;
        w/=3;
        System.out.println("w*=3 = "+w);
         int v=5;
        v%=3;
        System.out.println("v%=3 = "+v);
    }
    }

}
