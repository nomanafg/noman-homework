
package ansur14;

import java.util.Scanner;

public class Ansur14 {

  
    public static void main(String[] args) {
        Scanner input = new Scanner (System.in);
        double P;
        System.out.println("Enter The Principle");
        P = input.nextDouble();
        
        double R;
        System.out.println("Enter The Rate of interest");
        R= input.nextDouble();
        
        double T;
        System.out.println("Enter The Time");
        T = input. nextDouble();
        
        double IS = (P*R*T)/100d;
        System.out.println("the value of IS is "+ IS);
        
    }
    
}
