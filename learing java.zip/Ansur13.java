
package ansur13;

import java.util.Scanner;


public class Ansur13 {

 
    public static void main(String[] args) {
        double F,C;
        System.out.println("Please enter value for F");
        Scanner input = new Scanner(System. in);
        F = input.nextDouble();
        C = (32-F)*5/9;
        System.out.println("wather in C is " + C);    }
    
}
