
package ansur3;


public class Ansur3 {

   
    public static void main(String[] args) {
double a;
double b;
 a = 10;
 b = 20; 
        System.out.println("a+b is" + (a+b) );
        System.out.println("a-b is "+(a-b));
        System.out.println("a*b is "+(a*b));
        System.out.println("a/b is "+(a/b));
    }
    
}
