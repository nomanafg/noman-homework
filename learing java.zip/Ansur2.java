
package declarconstant;


public class DeclarConstant {

    
    public static void main(String[] args) {

final int AGE =20;
        System.out.println(AGE);}
    
}
