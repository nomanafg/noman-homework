
package answer18;

import java.util.Scanner;


public class Answer18 {


    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int num1,num2,num3,num4;
        System.out.println("Enter num1");
        num1=input.nextInt();
        
        System.out.println("Enter num2");
        num2=input.nextInt();
        
        System.out.println("Enter num3");
        num3=input.nextInt();
        
        System.out.println("Enter num4");
        num4=input.nextInt();
        
        int reverse;
        System.out.println("The reverse number of"+num1+""+num2+""+num3+""+num4+"is "+num4+""+num3+""+num2+""+num1);
    }
    
}
