
package ansur5;


public class Ansur5 {


    public static void main(String[] args) {

        String name,lastname;
        name = "Mohammad Noman" ;
        lastname= "Haqzada";
        System.out.println(name+ lastname);
    }
    
}
