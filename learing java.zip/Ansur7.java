
package ansur7;


public class Ansur7 {

    
    public static void main(String[] args) {
        int x = 15 ;
        int y = 4 ;
        System.out.println( "The remand is" + x %y);
    }
    
}
