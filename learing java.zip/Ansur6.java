package ansur.pkg6;

public class Ansur6 {

    public static void main(String[] args) {

        double number1 = 9.37d;
        int number2 = (int) (number1);
        System.out.println(number1);
        System.out.println(number2);

    }

}
