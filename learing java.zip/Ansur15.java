package ansur15;

import java.util.Scanner;

public class Ansur15 {

    public static void main(String[] args) {
        System.out.println(" Please enter valye for A");
        Scanner input1 = new Scanner(System.in);
        System.out.println(" Please enter valye for B");
        Scanner input2 = new Scanner(System.in);
        System.out.println(" Please enter valye for C");
        Scanner input3 = new Scanner(System.in);
        double X1,X2, A, B, C;
        A = input1.nextDouble();
        B = input2.nextDouble();

        C = input3.nextDouble();
        X1 = ((-B) + Math.sqrt(B*B -(4*A*C)))/2*A;
                X2 = ((-B) - Math.sqrt(B*B -(4*A*C)))/2*A;

        System.out.println("The value of X1   "+  X1);
                System.out.println("The value of X2  "+  X2);

    }

}
