
package ansur.pkg12;

import static java.io.FileDescriptor.in;
import java.util.Scanner;


public class ANSUR12 {

    
    public static void main(String[] args) {
        double area,redus;
        System.out.println("please enter value for redus");
        
        Scanner input = new Scanner (System .in);
        redus = input.nextInt();
        final double pi =3.14;
        
       area= (redus*redus*pi);
        System.out.println("The Area is"+area);
    }
    
}
