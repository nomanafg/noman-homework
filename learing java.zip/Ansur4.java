
package ansur4;


public class Ansur4 {

    
    public static void main(String[] args) {

char latter;
latter = 'A';

int number;
number = 100;
        System.out.println("The latter is" + latter); 
        System.out.println( "The number is"+ number);}
    
}
